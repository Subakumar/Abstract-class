package bb;

public class Circle extends Shape {
	
float radius;

public Double calculatePerimeter() {
	double area = 2*3.14*radius;
	return area;
	
}
public Circle() {
	
}
public Circle(float radius) {
	super();
	this.radius = radius;
}
public float getRadius() {
	return radius;
}
public void setRadius(float radius) {
	this.radius = radius;
}

}
