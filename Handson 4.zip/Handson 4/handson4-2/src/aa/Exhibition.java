package aa;

public class Exhibition extends Event {
int noOfStall;
public Exhibition() {
	
}
public Exhibition(int noOfStall) {
	super();
	this.noOfStall = noOfStall;
}
public int getNoOfStall() {
	return noOfStall;
}
public void setNoOfStall(int noOfStall) {
	this.noOfStall = noOfStall;
}

public Double projectedRevenue(Integer no) {
	double amount =no*10000;
	return amount;
}
}
