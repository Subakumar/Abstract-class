package aa;

public class Event {
protected String name;
protected String ownername;
protected String detail;

public Event() {
	
}

public Event(String name, String ownername, String detail) {
	super();
	this.name = name;
	this.ownername = ownername;
	this.detail = detail;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getOwnername() {
	return ownername;
}

public void setOwnername(String ownername) {
	this.ownername = ownername;
}

public String getDetail() {
	return detail;
}

public void setDetail(String detail) {
	this.detail = detail;
}

public Double projectedRevenue() {
	double amount = 0.0;
	return amount;
}
void display() {
	System.out.println("enter the name of the event:"+getName());
	System.out.println("enter the owner name of the event:"+getOwnername());
	System.out.println("enter the detail of the event:"+getDetail());
}

}
