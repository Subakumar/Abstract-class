package aa;
import java.util.*;

public class MainStage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Event e = new Event();
Scanner sc = new Scanner(System.in);

System.out.println("enter the name of the event:");
String name = sc.nextLine();
System.out.println("enter the owner name of the event:");
String ownername = sc.nextLine();
System.out.println("enter the detail of the event:");
String detail = sc.nextLine();
e.setName(name);
e.setOwnername(ownername);
e.setDetail(detail);
e.display();
System.out.println("enter the type of the event:");
System.out.println("1.Exhibition");
System.out.println("2.Stage Event");

System.out.println("enter the n:");
int n= sc.nextInt();

switch(n) {

case 1:
	System.out.println("enter the no.of stalls:");
	int no = sc.nextInt();
	
	Exhibition E = new Exhibition();
double amount1=	E.projectedRevenue(no);
System.out.println("The projected revenue of the event is:"+amount1);

break;

case 2:
	System.out.println("enter the number of show:");
	int num = sc.nextInt();
	
System.out.println("enter the no.of seats per show:");
int seat = sc.nextInt();
StageEvent s = new StageEvent();
double price1= s.projectedRevenue(seat,num);
System.out.println("The projected revenue is:"+price1);

	
	
	
}
	}

}
